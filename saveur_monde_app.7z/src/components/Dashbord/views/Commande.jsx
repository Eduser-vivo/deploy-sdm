import React from 'react'

export const Commande = () => {
    return (
        <div>
           Commande page
        </div>
    )
}
