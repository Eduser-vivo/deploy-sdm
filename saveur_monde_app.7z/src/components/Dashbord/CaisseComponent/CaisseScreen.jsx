import React from 'react'
import '../../styles/CaisseScreen.css'
export const CaisseScreen = () => {
    return (
        <div id="CaisseCreenId">
            Aucun Produit
        </div>
    )
}
